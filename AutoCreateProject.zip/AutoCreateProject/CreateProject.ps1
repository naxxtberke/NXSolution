# Türkçe karakter desteği için UTF-8 encoding ayarı
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8


# Ana proje adı ve WebAPI adı kullanıcıdan alınıyor
$appName = Read-Host "App Dosyasi Icin Isim"
$webApiName = Read-Host "API Icin Isim"

# Proje adlarının sonuna "App" ve "API" ekleniyor
$solutionName = "${appName}App"
$webApiName = "${solutionName}.${webApiName}API"

# Ana proje klasörü
$solutionPath = "$PSScriptRoot\$solutionName"

# Klasör yapısını oluştur
New-Item -Path $solutionPath -ItemType Directory
New-Item -Path "$solutionPath\Core" -ItemType Directory
New-Item -Path "$solutionPath\Infrastructure" -ItemType Directory
New-Item -Path "$solutionPath\Presentation" -ItemType Directory

# .NET Class Library projelerini oluştur
dotnet new classlib -n "$solutionName.Application" -o "$solutionPath\Core\$solutionName.Application"
dotnet new classlib -n "$solutionName.Domain" -o "$solutionPath\Core\$solutionName.Domain"
dotnet new classlib -n "$solutionName.Infrastructure" -o "$solutionPath\Infrastructure\$solutionName.Infrastructure"

# .NET WebAPI projesini oluştur
dotnet new webapi -n "$webApiName" -o "$solutionPath\Presentation\$webApiName"

# Solution dosyasını oluştur
dotnet new sln -n $solutionName -o $solutionPath

# Projeleri solution dosyasına ekle
dotnet sln "$solutionPath\$solutionName.sln" add "$solutionPath\Core\$solutionName.Application\$solutionName.Application.csproj"
dotnet sln "$solutionPath\$solutionName.sln" add "$solutionPath\Core\$solutionName.Domain\$solutionName.Domain.csproj"
dotnet sln "$solutionPath\$solutionName.sln" add "$solutionPath\Infrastructure\$solutionName.Infrastructure\$solutionName.Infrastructure.csproj"
dotnet sln "$solutionPath\$solutionName.sln" add "$solutionPath\Presentation\$webApiName\$webApiName.csproj"

# WebAPI projesindeki belirli dosyaları sil
$filesToDelete = @("DefaultWebApp.WebAPI.http", "appsettings.json", "Program.cs")
foreach ($file in $filesToDelete) {
    $filePath = "$solutionPath\Presentation\$webApiName\$file"
    if (Test-Path $filePath) {
        Remove-Item $filePath
        Write-Host "$file dosyasi silindi."
    } else {
        Write-Host "$file dosyasi bulunamadi: $filePath"
    }
}

# NeededFolder klasöründeki dosyaları WebAPI klasörüne kopyala
$neededFolderPath = "$PSScriptRoot\NeededFolder"
$destinationPath = "$solutionPath\Presentation\$webApiName"
if (Test-Path $neededFolderPath) {
    Copy-Item "$neededFolderPath\*" -Destination $destinationPath -Recurse -Force
    Write-Host "NeededFolder'daki dosyalar $destinationPath klasörüne kopyalandı."
} else {
    Write-Host "NeededFolder klasörü bulunamadı: $neededFolderPath"
}

Write-Host "Proje yapısı oluşturuldu!"
